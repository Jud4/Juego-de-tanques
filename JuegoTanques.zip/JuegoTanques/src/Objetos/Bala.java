package Objetos;

import javafx.scene.image.Image;

public class Bala extends ObjetosJuegoMov {

	public Bala(double x, double y, double angulo, int vida, Image i) {
		super(x, y, angulo, vida, i);

	}

	public void destruccion() {

	}
}
