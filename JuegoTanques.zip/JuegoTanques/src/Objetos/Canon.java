package Objetos;
import javafx.scene.image.Image;

public class Canon extends ObjetosJuegoMov {

	public Canon(double x, double y, double angulo, int vida, Image i) {
		super(x, y, angulo, vida, i);

	}

	public void apuntar() {

	}
}
