package Objetos;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ObjetosJuegoMov {
	private double x, y, angulo;
	private int vida;
	private Image tex;
	private ImageView iv;

	public ObjetosJuegoMov(double x, double y, double angulo, int vida, Image i) {
		this.angulo = angulo;
		this.x = x;
		this.y = y;
		this.angulo = angulo;
		this.vida = vida;
		this.tex = i;
		this.iv = new ImageView(i);
		this.iv.setLayoutX(x);
		this.iv.setLayoutY(y);
	}

	public void setPosicion(double y, double x) {
		this.y = y;
		this.x = x;

	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public void girarDer() {
		iv.setRotate(iv.getRotate() - angulo);
		if (iv.getRotate() < -315) {
			iv.setRotate(0);
		}
	}

	public void girarIzq() {
		iv.setRotate(iv.getRotate() + angulo);
		if (iv.getRotate() > 315) {
			iv.setRotate(0);
		}
	}

	public double getAngulo() {
		return angulo;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public void tiempoDisparo() {

	}

	public void destruir() {

	}

	public ImageView render() {
		return iv;
	}

}
