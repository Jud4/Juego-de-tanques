package Objetos;

import javafx.scene.image.Image;

public class Tank extends ObjetosJuegoMov {

	public Tank(double x, double y, double angulo, int vida, Image i) {
		super(x, y, angulo, vida, i);
		// TODO Auto-generated constructor stub
	}

	public void moverse() {
		if (this.render().getRotate() == 0) {
			this.render().setLayoutX(this.render().getLayoutX() + 10);
		}
		if (this.render().getRotate() == 45 || this.render().getRotate() == -315) {
			this.render().setLayoutX(this.render().getLayoutX() + 10);
			this.render().setLayoutY(this.render().getLayoutY() + 10);
		}
		if (this.render().getRotate() == 135 || this.render().getRotate() == -225) {
			this.render().setLayoutX(this.render().getLayoutX() - 10);
			this.render().setLayoutY(this.render().getLayoutY() + 10);
		}
		if (this.render().getRotate() == 225 || this.render().getRotate() == -135) {
			this.render().setLayoutX(this.render().getLayoutX() - 10);
			this.render().setLayoutY(this.render().getLayoutY() - 10);
		}
		if (this.render().getRotate() == 315 || this.render().getRotate() == -45) {
			this.render().setLayoutX(this.render().getLayoutX() + 10);
			this.render().setLayoutY(this.render().getLayoutY() - 10);
		}
		if (this.render().getRotate() == 180 || this.render().getRotate() == -180) {
			this.render().setLayoutX(this.render().getLayoutX() - 10);
		}
		if (this.render().getRotate() == 90 || this.render().getRotate() == -270) {
			this.render().setLayoutY(this.render().getLayoutY() + 10);
		}
		if (this.render().getRotate() == 270 || this.render().getRotate() == -90) {
			this.render().setLayoutY(this.render().getLayoutY() - 10);
		}
	}
}
