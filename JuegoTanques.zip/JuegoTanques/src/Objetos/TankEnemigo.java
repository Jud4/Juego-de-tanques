package Objetos;

import javafx.scene.image.Image;

public class TankEnemigo extends Tank {
	private double x, y;

	public TankEnemigo(double x, double y, double angulo, int vida, Image i, double x2, double y2) {
		super(x, y, angulo, vida, i);
		this.x = x2;
		this.y = y2;
	}

	public void perseguir() {

	}
}
