package Objetos;

import javafx.scene.image.Image;

public class TankJugador extends Tank {

	public TankJugador(double x, double y, double angulo, int vida, Image i) {
		super(x, y, angulo, vida, i);

	}

}
