package application;

import Objetos.TankJugador;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Main extends Application {
	public Niveles level;
	private TankJugador jugador;

	@Override
	public void start(Stage primaryStage) {
		try {
			this.jugador = new TankJugador(10, 200, 45, 3, new Image("/player.png"));
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root, 400, 400);
			root.getChildren().add(this.jugador.render());

			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
