package application;

import Objetos.Bala;
import Objetos.Canon;
import Objetos.TankEnemigo;
import Objetos.TankJugador;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;

public class Niveles {
	private TankJugador jugador;
	private Canon boss;
	private Canon miniboss;
	private Bala bala;
	private TankEnemigo enemy;
	private Scene lv1;
	private Scene lv2;
	private Scene lv3;
	private AnchorPane r1;
	private AnchorPane r2;
	private AnchorPane r3;
	private double angle = 0;

	public Niveles() {
		this.jugador = new TankJugador(10, 200, 45, 3, new Image("/player.png"));
		this.r1 = new AnchorPane();
		this.r2 = new AnchorPane();
		this.r3 = new AnchorPane();

		this.lv2 = new Scene(r2);
		this.lv3 = new Scene(r3);
	}

	public void creaLv1() {
		this.r1.getChildren().add(this.jugador.render());
		this.lv1 = new Scene(r1);
	}

	public void creaLv2() {

	}

	public void creaLv3() {

	}

	public Scene getLv1() {
		return lv1;
	}

	public Scene getLv2() {
		return lv2;
	}

	public Scene getLv3() {
		return lv3;
	}

}
