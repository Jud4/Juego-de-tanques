package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Prueba {

	ImageView iv;

	public Prueba(Image i) {
		this.iv = new ImageView(i);
	}

	public void setPosi(double x, double y) {
		iv.setLayoutX(x);
		iv.setLayoutY(y);
	}

	public ImageView getIv() {
		return iv;
	}
}
