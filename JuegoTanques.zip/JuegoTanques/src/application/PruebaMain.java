package application;

import static javafx.scene.input.KeyCode.ENTER;
import static javafx.scene.input.KeyCode.LEFT;
import static javafx.scene.input.KeyCode.RIGHT;
import static javafx.scene.input.KeyCode.UP;

import Objetos.Canon;
import Objetos.TankJugador;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PruebaMain extends Application {
	public Niveles level;
	private TankJugador jugador;
	private Image i = new Image("/tank.png");
	private Image j = new Image("/canon.png");
	private Canon canon;

	@Override
	public void start(Stage primaryStage) {
		try {
			Circle pelota = new Circle(10, Color.GOLD);
			this.jugador = new TankJugador(10, 200, 45, 3, i);

			BorderPane root = new BorderPane();
			Scene scene = new Scene(root, 400, 400);
			ImageView iv = jugador.render();
			Bounds limites = root.getBoundsInLocal();
			this.canon = new Canon(300, 200, 15, 5, j);
			ImageView cn = canon.render();
			root.getChildren().addAll(iv, cn, pelota);
			scene.addEventFilter(KeyEvent.KEY_PRESSED, (KeyEvent keyEvent) -> {
				if (keyEvent.getCode() == UP) {
					jugador.moverse();
					pelota.relocate(jugador.render().getLayoutX(), jugador.render().getLayoutY());
				}
				if (keyEvent.getCode() == ENTER) {
					// valores para que la pelota se mueva en linea recta

					pelota.relocate(jugador.render().getLayoutX(), jugador.render().getLayoutY());
					KeyValue valor = new KeyValue(pelota.layoutXProperty(), limites.getMaxX() - pelota.getRadius());
					KeyFrame unFrame = new KeyFrame(Duration.seconds(1), valor);
					Timeline timeline = new Timeline(unFrame);

					timeline.setCycleCount(1);
					timeline.play();
//					root.getChildren().remove(pelota);
				}
				if (keyEvent.getCode() == LEFT) {
					jugador.girarDer();
					System.out.println(iv.getRotate());
//					root.getChildren().remove(pelota);
				}
				if (keyEvent.getCode() == RIGHT) {
					jugador.girarIzq();
					System.out.println(iv.getRotate());
				}
			});

			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();

		} catch (

		Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		launch(args);
	}
}
