package application;

import javafx.scene.image.Image;

public class Bala extends Sprite {
	public Bala(VistaMision missionView, double x, double y, double rotation) {
		super(missionView, x, y, rotation, new Image("/red-ball.png"));
		this.ocultar();
		this.nombre = "Bullet";
	}

	public void kill() {

	}

}