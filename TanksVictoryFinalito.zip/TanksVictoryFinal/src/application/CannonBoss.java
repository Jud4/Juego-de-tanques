package application;

import javafx.scene.image.Image;

public class CannonBoss extends Disparador {
	public CannonBoss(VistaMision missionView, double x, double y, double rotation) {
		super(missionView, x, y, rotation, 5);
		this.setImage(new Image("/canon.png"));
		this.vidas = 5;
		this.nombre = "Cannon Boss";
	}
}
