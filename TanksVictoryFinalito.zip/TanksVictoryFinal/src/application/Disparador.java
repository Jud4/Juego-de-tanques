package application;

import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;

public abstract class Disparador extends Sprite {
	private ArrayList<Bala> sprites;

	public Disparador(VistaMision missionView, double x, double y, double rotation, int numberOfBullets) {
		super(missionView, x, y, rotation);
		this.sprites = new ArrayList<Bala>();
		for (int i = 0; i <= numberOfBullets; i++) {
			this.sprites.add(new Bala(missionView, x, y, rotation));
		}
	}

	public void setX(double x) {
		super.setX(x);
		if (this.sprites == null) return;
		for (Bala bullet : this.sprites) {
			bullet.setX(x);
		}
	}

	public void setY(double y) {
		super.setY(y);
		if (this.sprites == null) return;
		for (Sprite sprite : this.sprites) {
			sprite.setY(y);
		}
	}

	public void rotarIzq() {
		super.rotarIzq();
		for (Sprite sprite : this.sprites) {
			sprite.rotarIzq();
		}
	}

	public void rotarDer() {
		super.rotarDer();
		for (Sprite sprite : this.sprites) {
			sprite.rotarDer();
		}
	}

	public void fire() {
		if (this.sprites.size() > 0) {
			Bala bullet = this.sprites.remove(this.sprites.size() - 1);
			Sprite firer = this;
			bullet.mostrar();
			Timeline timeline = new Timeline();
			timeline.getKeyFrames().add(new KeyFrame(Duration.millis(20), new EventHandler<ActionEvent>() {
				@Override public void handle(ActionEvent t) {
					bullet.avanzar();
					// Verifying if the bullet hits the enemy
					Sprite intersected = bullet.choqueConOtroSprite(firer);
					if (intersected != null) {
						intersected.kill();
						timeline.stop();
						bullet.ocultar();
					}
				}
			}));

			timeline.setCycleCount(Animation.INDEFINITE);

			timeline.play();
//			bullet.ocultar();
		}
	}
}