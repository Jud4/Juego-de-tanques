package application;

import java.util.Timer;
import java.util.TimerTask;

public class NonPlayerCharacter {
	Disparador firer;
	PlayerCharacter player;

	public NonPlayerCharacter(Disparador firer, PlayerCharacter pc) {
		this.firer = firer;
		this.player = pc;
		this.initBrain();
	}

	private void initBrain() {
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			public void run() {
				tratarDeMatarJugador();
			}
		};

		timer.schedule(task, 1000, 5000);
	}

	private void tratarDeMatarJugador() {
		double x = this.player.getXLocation();
		double y = this.player.getYLocation();

		// TODO: get the right angle
		double rotation = 450;
		this.firer.setRotation(rotation);
		this.firer.fire();
	}
}
