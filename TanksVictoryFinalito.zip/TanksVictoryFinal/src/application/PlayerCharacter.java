package application;

import static javafx.scene.input.KeyCode.LEFT;
import static javafx.scene.input.KeyCode.RIGHT;
import static javafx.scene.input.KeyCode.SPACE;
import static javafx.scene.input.KeyCode.UP;

import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;

public class PlayerCharacter {
	private Disparador firer;

	public PlayerCharacter(Scene scene, Disparador firer) {
		this.firer = firer;

		scene.addEventFilter(KeyEvent.KEY_PRESSED, (KeyEvent keyEvent) -> {
			if (keyEvent.getCode() == UP) {
				this.firer.avanzar();
			}
//			
			if (keyEvent.getCode() == LEFT) {
				this.firer.rotarIzq();
			}

			if (keyEvent.getCode() == RIGHT) {
				this.firer.rotarDer();
			}

			if (keyEvent.getCode() == SPACE) {
				this.firer.fire();
			}
		});
	}

	public double getXLocation() {
		return this.firer.getX();
	}

	public double getYLocation() {
		return this.firer.getY();
	}
}
