package application;

import javafx.scene.image.Image;

public class Tanque extends Disparador {
	public Tanque(VistaMision missionView, double x, double y, double rotation) {
		super(missionView, x, y, rotation, 4);
		this.setImage(new Image("/tank.png"));
		this.vidas = 3;
		this.nombre = "Tank";
	}

}
