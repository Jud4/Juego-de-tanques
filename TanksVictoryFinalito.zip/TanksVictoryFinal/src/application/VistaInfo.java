package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class VistaInfo extends VistaTotalJuego {
	private Stage stage;

	public VistaInfo(Stage stage) {
		this.stage = stage;
		this.initTexto();
	}

	private void initTexto() {
		Text titulo = new Text("Objetivo");
		Text objetivo = new Text(
				"1. Maneja a tu tanque usando las teclas izquierda y derecha para girar\ny arriba para avanzar\n\n2. Para disparar usa la tecla espacio\n\n****Evita que el canon que esta al otro lado te pesque con sus balas****\n***Si recibes 3 disparos del canon seras llevado al menu***\n**Si, en cambio, tu le das 5 disparos...**\n*Igual iras al menu ^_^*");
		titulo.setFont(new Font(80));
		objetivo.setFont(new Font(20));
		titulo.relocate(300, 0);
		objetivo.relocate(10, 250);
		Button salir = new Button("Volver");
		salir.setOnAction(new ManejadorVolver());

		this.getRoot().getChildren().addAll(titulo, objetivo, salir);
	}

	class ManejadorVolver implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			VistaTotalJuego view = new VistaMenu(stage);
			stage.setScene(view.getDefaultScene());
		}
	}
}
