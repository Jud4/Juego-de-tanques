package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class VistaMenu extends VistaTotalJuego {
	private Button jugar;
	private Button instruccion;
	private Button salir;
	private Stage stage;

	public VistaMenu(Stage stage) {
		super();
		this.stage = stage;
		this.initBotones();
	}

	private void initBotones() {
		this.jugar = new Button("Mision");
		this.instruccion = new Button("Objetivo");
		this.salir = new Button("Desertar");

		this.jugar.setOnAction(new ManejadorJugar());
		this.instruccion.setOnAction(new ManejadorInstrucciones());
		this.salir.setOnAction(new ExitButtonHandler());

		this.getDefaultScene();

		double middleX = this.getRoot().widthProperty().divide(2).doubleValue();
		double middleY = this.getRoot().heightProperty().divide(2).doubleValue();

		this.jugar.relocate(middleX - 50, middleY - 50);
		this.instruccion.relocate(middleX - 50, middleY);
		this.salir.relocate(middleX - 50, middleY + 50);

		Text title = new Text("Tanks: Area 11 to the victory");
		title.setFont(new Font(60));
		title.relocate(30, 50);

		this.getRoot().getChildren().addAll(jugar, instruccion, salir, title);
	}

	class ManejadorJugar implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			VistaTotalJuego view = new VistaMision();
			stage.setScene(view.getDefaultScene());
		}
	}

	class ManejadorInstrucciones implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			VistaTotalJuego view = new VistaInfo(stage);
			stage.setScene(view.getDefaultScene());
		}
	}

	class ExitButtonHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.exit(0);
		}
	}
}
