package application;

import java.util.ArrayList;

import javafx.scene.control.Label;

public class VistaMision extends VistaTotalJuego {

	private ArrayList<Sprite> sprites;

	public ArrayList<Sprite> getSprites() {
		return sprites;
	}

	public VistaMision() {
		this.initTexto();
		this.sprites = new ArrayList<Sprite>();
		this.initSprites();

	}

	private void initTexto() {
		Label text = new Label("Mision");
		this.getRoot().getChildren().addAll(text);
	}

	private void initSprites() {
		Tanque tank = new Tanque(this, 10, 100, 0);
		CannonBoss cannon = new CannonBoss(this, 700, 380, 180);

		PlayerCharacter pc = new PlayerCharacter(this.getDefaultScene(), tank);
		NonPlayerCharacter npc = new NonPlayerCharacter(cannon, pc);

	}

	public void addSprite(Sprite sprite) {
		this.sprites.add(sprite);
		this.getRoot().getChildren().add(sprite.render());
	}

	public void gameOver() {
		// TODO Come back to the menu

		System.out.println("Game OVer");
	}
}
