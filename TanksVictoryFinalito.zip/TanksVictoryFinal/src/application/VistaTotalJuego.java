package application;

import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public abstract class VistaTotalJuego {

	private Scene defaultScene;
	private Pane root;

	protected Pane getRoot() {
		if (this.root == null) {
			this.root = new AnchorPane();
		}

		return this.root;
	}

	public Scene getDefaultScene() {
		int size = 800;

		if (this.defaultScene == null) {
			this.defaultScene = new Scene(this.getRoot(), size, size);
		}

		return this.defaultScene;
	}
}
